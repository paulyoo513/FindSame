package jframe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class FindSameJFrame {
	public static void mainScreen() {
		JFrame frame = new JFrame("FindSame");
		frame.setSize(470, 670);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null); // 화면 중앙에 프레임 표시

		JPanel panel = new JPanel(new BorderLayout());
		JLabel textLabel = new JLabel("Find Same");
		textLabel.setFont(new Font("NanumGothic", Font.BOLD, 50));
		textLabel.setHorizontalAlignment(JLabel.CENTER);
		textLabel.setBorder(new EmptyBorder(50, 0, 0, 0));
		panel.add(textLabel, BorderLayout.PAGE_START);

		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton gameButton = new JButton("Game Start");
		gameButton.setFont(new Font("NanumGothic", Font.BOLD, 20));
		gameButton.setPreferredSize(new Dimension(200, 70)); // 버튼 크기 설정
		gameButton.setBackground(Color.white);
		buttonPanel.add(gameButton);

		JButton rankButton = new JButton("Rank"); // Rank 버튼 생성
		rankButton.setFont(new Font("NanumGothic", Font.BOLD, 20));
		rankButton.setPreferredSize(new Dimension(200, 70)); // 버튼 크기 설정
		rankButton.setBackground(Color.white);
		buttonPanel.add(rankButton);
		panel.add(buttonPanel, BorderLayout.CENTER);
		buttonPanel.setBorder(new EmptyBorder(50, 60, 0, 50));

		gameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				FindSame.gameStart(); // 여기서 gameStart 메소드를 호출합니다.
			}
		});
		rankButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				FindSame.rankSystem(); // 여기서 Rank 시스템 호출
			}
		});

		// 이스터에그 완료(로고)
		frame.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();

				// 클릭 이벤트를 처리할 특정 영역의 좌표와 크기
				int targetX = 110;
				int targetY = 90;
				int targetWidth = 240;
				int targetHeight = 55;

				if (x >= targetX && x <= targetX + targetWidth && y >= targetY && y <= targetY + targetHeight) {
					// 특정 영역이 클릭되었을 때 원하는 동작 수행
					JLabel label = new JLabel("<html>1팀 프로젝트<br>Find Same</html>");
					label.setHorizontalAlignment(SwingConstants.CENTER);

					JDialog dialog = new JDialog();
					dialog.setModal(true);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.getContentPane().add(label);
					
					// 폰트 컬러를 조정하여 설정합니다.
//			        Color fontColor = Color.RED;
//			        label.setForeground(fontColor);
			        
					// 폰트 크기를 조정하여 설정합니다.
			        Font font = label.getFont();
			        Font newFont = font.deriveFont(18f);
			        label.setFont(newFont);
			        
					// 다이얼로그의 크기를 설정합니다.
					Dimension dialogSize = new Dimension(300, 150); // 원하는 크기로 변경하세요
					dialog.setPreferredSize(dialogSize);
					dialog.pack();
					dialog.setLocationRelativeTo(null);
					dialog.setVisible(true);
				}
			}
		});

		// 이스터에그 완료(똑단발)
		frame.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();

				// 클릭 이벤트를 처리할 특정 영역의 좌표와 크기
				int targetX = 260;
				int targetY = 537;
				int targetWidth = 142;
				int targetHeight = 117;

				if (x >= targetX && x <= targetX + targetWidth && y >= targetY && y <= targetY + targetHeight) {
					// 특정 영역이 클릭되었을 때 원하는 동작 수행
					JLabel label = new JLabel("<html>1 팀 팀 장<br><font color='YELLOW'>심 완 석</html>");
					label.setHorizontalAlignment(SwingConstants.CENTER);

					JDialog dialog = new JDialog();
					dialog.setModal(true);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.getContentPane().add(label);
			        
					// 폰트 크기를 조정하여 설정합니다.
			        Font font = label.getFont();
			        Font newFont = font.deriveFont(18f);
			        label.setFont(newFont);
			        
					// 다이얼로그의 크기를 설정합니다.
					Dimension dialogSize = new Dimension(300, 150); // 원하는 크기로 변경하세요
					dialog.setPreferredSize(dialogSize);
					dialog.pack();
					dialog.setLocationRelativeTo(null);
					dialog.setVisible(true);
				}
			}
		});

		// 이스터에그 완료(토끼)
		frame.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();

				// 클릭 이벤트를 처리할 특정 영역의 좌표와 크기
				int targetX = 66;
				int targetY = 562;
				int targetWidth = 103;
				int targetHeight = 94;

				if (x >= targetX && x <= targetX + targetWidth && y >= targetY && y <= targetY + targetHeight) {
					// 특정 영역이 클릭되었을 때 원하는 동작 수행
					JLabel label = new JLabel("<html>유 바 울</html>");
					label.setHorizontalAlignment(SwingConstants.CENTER);

					JDialog dialog = new JDialog();
					dialog.setModal(true);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.getContentPane().add(label);
			        
					// 폰트 크기를 조정하여 설정합니다.
			        Font font = label.getFont();
			        Font newFont = font.deriveFont(18f);
			        label.setFont(newFont);
			        
					// 다이얼로그의 크기를 설정합니다.
					Dimension dialogSize = new Dimension(300, 150); // 원하는 크기로 변경하세요
					dialog.setPreferredSize(dialogSize);
					dialog.pack();
					dialog.setLocationRelativeTo(null);
					dialog.setVisible(true);
				}
			}
		});


		frame.getContentPane().add(panel, BorderLayout.CENTER);
		String imgBg = "/img/bg.png";
		ImageIcon imageIcon = new ImageIcon(FindSameJFrame.class.getResource(imgBg));
		JLabel imageLabel = new JLabel(imageIcon);
		frame.getContentPane().add(imageLabel, BorderLayout.SOUTH);
		frame.setVisible(true);
	}
}