package jframe;

public class Player {
	private int Time2;
	private String playername;
	public Player() {
	}
	public Player( String playername,int time) {
		this.Time2 = time;
		this.playername = playername;
	}
	
	public String getPlayername() {
		return playername;
	}
	public int getTime2() {
		return Time2;
	}
}