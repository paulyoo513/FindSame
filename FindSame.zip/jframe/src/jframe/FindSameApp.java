package jframe;

public class FindSameApp {
	public static void main(String[] args) {
		Player f = new Player("전윤수", 25);
		Player d = new Player("심완석", 14);
		Player b = new Player("유바울", 1);
		Player c = new Player("유혜지", 3);
		FindSame.arr.add(d);
		FindSame.arr.add(b);
		FindSame.arr.add(c);
		FindSame.arr.add(f);
		FindSameJFrame.mainScreen();
		
	}
}
