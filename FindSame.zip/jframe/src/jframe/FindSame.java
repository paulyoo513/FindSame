package jframe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class FindSame {
	private static final int IMAGE_COUNT = 16;
	private static final ImageIcon NULL_IMAGE_ICON = new ImageIcon(FindSame.class.getResource("/img/null.png"));
	private static final int DELAY_TIME = 500; // 0.5초
	private static int firstIndex = -1; // 첫 번째 클릭된 이미지 인덱스
	private static int secondIndex = -1; // 두 번째 클릭된 이미지 인덱스
	private static Timer timer; // 이미지 숨기기를 위한 타이머 객체
	private static JPanel mainPanel; // 메인 패널
	private static JLabel timerLabel;
	private static Timer timer2;
	private static int remainingTime2;
	private static JFrame frame; // 프레임 변수
	static ArrayList<Player> arr = new ArrayList<>();
	static String myrank;
	

	public static void gameStart() {
		frame = new JFrame("Find Same Game");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(470, 670); // 프레임 크기 설정
		frame.setLocationRelativeTo(null); // 화면 중앙에 프레임 표시
		frame.getContentPane().setBackground(Color.CYAN); // 하늘색으로 설정

		mainPanel = new JPanel(new GridLayout(4, 4, 10, 10));    
		
		mainPanel.setPreferredSize(new Dimension(450, 600));
		mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
		frame.add(mainPanel); // mainPanel을 프레임에 추가

		JPanel timerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		timerLabel = new JLabel("Remaining Time: 100");
		timerLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		timerPanel.add(timerLabel);
		frame.add(timerPanel, BorderLayout.NORTH);

		startTimer();

		// 이미지 파일 경로
		String[] imagePaths = { "/img/card1.png", "/img/card2.png", "/img/card3.png", "/img/card4.png",
				"/img/card5.png", "/img/card6.png", "/img/card7.png", "/img/card8.png", "/img/card1.png",
				"/img/card2.png", "/img/card3.png", "/img/card4.png", "/img/card5.png", "/img/card6.png",
				"/img/card7.png", "/img/card8.png" };

		// 이미지 아이콘 생성
		ImageIcon[] imageIcons = new ImageIcon[IMAGE_COUNT];
		for (int i = 0; i < IMAGE_COUNT; i++) {
			imageIcons[i] = new ImageIcon(FindSame.class.getResource(imagePaths[i]));
		}
		// 사용하여 이미지 아이콘을 랜덤하게 섞음
		Random random = new Random();
		for (int i = imageIcons.length - 1; i > 0; i--) {
			int j = random.nextInt(i + 1);
			ImageIcon temp = imageIcons[i];
			imageIcons[i] = imageIcons[j];
			imageIcons[j] = temp;
		}
		// 이미지를 표시할 라벨 생성 및 패널에 추가
		JLabel[] imageLabels = new JLabel[IMAGE_COUNT];
		boolean[] isFlipped = new boolean[IMAGE_COUNT]; // 이미지가 뒤집혔는지 여부를 저장하는 배열
		for (int i = 0; i < IMAGE_COUNT; i++) {
		    JPanel panel = new JPanel();
		    mainPanel.add(panel);
		    imageLabels[i] = new JLabel(imageIcons[i]); // null 이미지 대신에 imageIcons 배열의 이미지로 설정
		    panel.add(imageLabels[i]);
		    if(isFlipped[i] == true) {
		    	
		    } // 이미지가 보여지도록 isFlipped 배열을 true로 설정
		}
		

		// 전체 이미지를 1초 동안 보여주고 다시 null 이미지로 변경하기 위한 Timer 객체 생성
		    Timer nullTimer = new Timer(1000, evt -> {
		        for (int i = 0; i < IMAGE_COUNT; i++) {
		            imageLabels[i].setIcon(NULL_IMAGE_ICON); // null 이미지로 변경
		            isFlipped[i] = false;
		        }
		    });
		    nullTimer.setRepeats(false); // 한 번만 실행되도록 설정
		    nullTimer.start(); // nullTimer 시작

		// 이미지 라벨에 클릭 이벤트 처리
		for (int i = 0; i < IMAGE_COUNT; i++) {
			final int index = i;
			imageLabels[i].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					if (!isFlipped[index] ) {
						imageLabels[index].setIcon(imageIcons[index]); // 이미지 변경
						isFlipped[index] = true;
						// 첫 번째 클릭된 이미지 처리
						if (firstIndex == -1) {  //클릭안된상태로                                                                             //-1
							firstIndex = index;
						} else {
							secondIndex = index;
							checkMatching(imageLabels, imageIcons, isFlipped); // 매칭 확인
						}
						
					}
				}
				
			});
		}
		frame.setVisible(true);
	}

	public static void rankSystem() {
		for (int i = 0; i < arr.size() - 1; i++) {   
			for (int j = i + 1; j < arr.size(); j++) {
				Player a = new Player();////연관관계
				if (arr.get(i).getTime2() < arr.get(j).getTime2()) {  ////
					a = arr.get(i);
					arr.set(i, arr.get(j));
					arr.set(j, a);
				}
			}
		}
		int count = Math.min(arr.size(), 10);
		frame = new JFrame("World Ranking");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(470, 670); // 프레임 크기 설정
		frame.setLocationRelativeTo(null); // 화면 중앙에 프레임 표시
		frame.getContentPane().setBackground(new Color(0, 0, 0, 0));

		// 새로운 버튼 생성
		JButton mainbtn = new JButton("메인화면");
		mainbtn.setFont(new Font("NanumGothic", Font.BOLD, 12));
		mainbtn.setBackground(Color.white);
		mainbtn.setBounds(frame.getWidth() - 150, 550, 100, 50); // 버튼 위치 설정 (오른쪽 상단 구석)
		mainbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose(); // 현재 프레임 닫기
				FindSameJFrame.mainScreen(); // 메인 프레임 보여주는 메서드 호출
			}
		});

		frame.getContentPane().setLayout(null); // 레이아웃을 null로 설정하여 수동으로 컴포넌트 위치 조정 가능
		frame.getContentPane().add(mainbtn); // 버튼을 프레임에 추가

		// 새로운 버튼 생성2
		JButton gamebtn = new JButton("게임시작");
		gamebtn.setFont(new Font("NanumGothic", Font.BOLD, 12));
		gamebtn.setBackground(Color.white);
		gamebtn.setBounds(frame.getWidth() - 270, 550, 100, 50); // 버튼 위치 설정 (오른쪽 상단 구석)
		gamebtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose(); // 현재 프레임 닫기
				gameStart(); // 게임 프레임 보여주는 메서드 호출
			}
		});
		frame.getContentPane().setLayout(null); // 레이아웃을 null로 설정하여 수동으로 컴포넌트 위치 조정 가능
		frame.getContentPane().add(gamebtn); // 버튼을 프레임에 추가
		JPanel rankingPanel = new JPanel();
		int panelHeight = Math.min(400, (count + 1) * 40);
		rankingPanel.setBounds(50, 50, 370, panelHeight);
		rankingPanel.setLayout(new GridLayout(count + 1, 1));

		// 이름과 남은 시간을 포함한 랭킹 데이터가 필요합니다.
		JLabel rankLabe2 = new JLabel("등수" + "           " + "이 름" + "            " + "남은 시간(s)");
		rankLabe2.setHorizontalAlignment(JLabel.LEFT);
		rankLabe2.setFont(rankLabe2.getFont().deriveFont(20f));
		rankingPanel.add(rankLabe2);
		
		rankLabe2.setHorizontalAlignment(JLabel.LEFT);
		rankLabe2.setFont(rankLabe2.getFont().deriveFont(20f));
		rankingPanel.add(rankLabe2);

		// 상위 10개의 랭킹 데이터를 표시합니다.
		for (int i = 0; i < count; i++) {JLabel rankLabel = new JLabel(" " + (i + 1) + "              " + arr.get(i).getPlayername()
		        + "                        " + arr.get(i).getTime2());
		rankLabel.setHorizontalAlignment(JLabel.LEFT);
		rankLabel.setFont(rankLabel.getFont().deriveFont(20f));
		rankLabel.setPreferredSize(new Dimension(400, 30)); // 크기 고정
		rankLabel.setMaximumSize(rankLabel.getPreferredSize()); // 크기 고정
		rankingPanel.add(rankLabel);
		}
		
		frame.getContentPane().add(rankingPanel);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);

	}

	// 매칭 확인 메소드
	private static void checkMatching(JLabel[] labels, ImageIcon[] icons, boolean[] isFlipped) {
		// 이미지가 2개 뒤집혔을 때 매칭 확인
		if (firstIndex != -1 && secondIndex != -1) {
			if (isImagesEqual(icons[firstIndex], icons[secondIndex])) {				
				// 이미지가 일치하는 경우
				firstIndex = -1;
				secondIndex = -1;
				checkGameComplete(isFlipped);                                                                            //match isFlipped
				// 시간 +
				// remainingTime2 += 5;
				// timerLabel.setText("남은 시간: " + remainingTime2);
				
			} else {
				// 이미지가 일치하지 않는 경우 0.5초 후에 이미지를 다시 null 이미지로 변경
				timer = new Timer(DELAY_TIME, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						labels[firstIndex].setIcon(NULL_IMAGE_ICON);
						labels[secondIndex].setIcon(NULL_IMAGE_ICON);
						isFlipped[firstIndex] = false;                                                                    //매치 안됐으면 뒤집기 ??
						isFlipped[secondIndex] = false;
						firstIndex = -1;
						secondIndex = -1;
					}
				});
				timer.setRepeats(false);
				timer.start();
				// 시간 -2
				remainingTime2 -= 2;
				timerLabel.setText("남은 시간: " + remainingTime2);

				if (remainingTime2 <= 0) {
					timer2.stop();
					showGameOverDialog();
				}
			}
		}
	}

	// 두 이미지가 일치하는지 비교하는 메소드
	private static boolean isImagesEqual(ImageIcon icon1, ImageIcon icon2) {
		return icon1.getDescription().equals(icon2.getDescription());                                                        //getDescription()??
	}

	// 게임이 완료되었는지 확인하는 메소드
	private static void checkGameComplete(boolean[] isFlipped) {
		boolean allMatched = true;
		for (boolean flipped : isFlipped) {                                                                                  //
			if (!flipped) {
				allMatched = false;
				break;
			}
		}
		if (allMatched) {
			// 모든 이미지가 매칭되어 게임이 완료된 경우
			showGameCompleteDialog();
		}
	}

	private static void startTimer() {
		remainingTime2 = 60;
		timerLabel.setText("남은 시간: " + remainingTime2);

		timer2 = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				remainingTime2--;
				timerLabel.setText("남은 시간: " + remainingTime2);

				if (remainingTime2 <= 0) {// 0초가 되면 게임 오버
					timer2.stop();
					showGameOverDialog();
				}
			}
		});
		timer2.start();
	}

	private static void showGameCompleteDialog() {
		timer2.stop();
		String playerName = JOptionPane.showInputDialog(frame, "이름을 입력하세요:");
		arr.add(new Player(playerName, remainingTime2));
		int aaa = 0;
		for (int i = 0; i < arr.size() - 1; i++) {
			for (int j = i + 1; j < arr.size(); j++) {
				Player a = new Player();
				if (arr.get(i).getTime2() < arr.get(j).getTime2()) {
					a = arr.get(i);
					arr.set(i, arr.get(j));
					arr.set(j, a);
				}
			}
		}
		for(int i = 0;i<arr.size();i++) {
			if(arr.get(i).getPlayername().equals(playerName)) {
				aaa = i+1;
			}
		}
		
		myrank=" 등수는 " + aaa + "등 입니다.   " + "(남은 시간 : "+remainingTime2+")";
		
		
		
		if (playerName != null) {
			String imgBg = "/img/complete.png";
			// 이미지 아이콘 생성
			ImageIcon imageIcon = new ImageIcon(FindSame.class.getResource(imgBg));
			JPanel dialogPanel = new JPanel(new BorderLayout());                       //  기본 컴포넌트 위치는 center, south, north, east, west이고 더 많은 컴포넌트를 결합해 넣으려면 panel이용.
			JLabel imageLabel = new JLabel(imageIcon);   
			// 플레이어의 등수를 알려주는 라벨 생성
			JLabel myrankLabel = new JLabel(playerName+"님" + myrank);
			myrankLabel.setBorder(BorderFactory.createEmptyBorder(40, 70, 0, 0));
			dialogPanel.add(myrankLabel, BorderLayout.NORTH);
			dialogPanel.add(imageLabel, BorderLayout.CENTER);
			
			
			JPanel buttonPanel = new JPanel(new FlowLayout());
			JButton checkButton = new JButton("확인");
			JButton restartButton = new JButton("재시작");
			
			// 버튼의 가로와 세로 크기를 설정합니다.
			checkButton.setPreferredSize(new Dimension(150, 50)); // 가로 100, 세로 50
			restartButton.setPreferredSize(new Dimension(150, 50)); // 가로 100, 세로 50
			// 배경색을 설정합니다.
			checkButton.setBackground(Color.white); // 배경색을 흰색으로 설정
			restartButton.setBackground(Color.white); // 배경색을 흰색으로 설정
			
			buttonPanel.add(checkButton);
			buttonPanel.add(restartButton);
			
			dialogPanel.add(buttonPanel, BorderLayout.SOUTH);
			
			
			
			JFrame dialogFrame = new JFrame("게임 완료");
			dialogFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			dialogFrame.getContentPane().add(dialogPanel);
			dialogFrame.setSize(400, 400);
			dialogFrame.setLocationRelativeTo(mainPanel);
			dialogFrame.setVisible(true);
			
			checkButton.addActionListener(new ActionListener() {   //익명클래스
				@Override
				public void actionPerformed(ActionEvent e) {
					dialogFrame.dispose(); // 다이얼로그 창 닫기
					frame.dispose();
					FindSameJFrame.mainScreen();
				}
			});
			restartButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					dialogFrame.dispose(); // 다이얼로그 창 닫기
					frame.dispose();
					resetGame();
				}
			});
			
		}
	}

	private static void showGameOverDialog() {
		String imgBg = "/img/over.png";
		ImageIcon imageIcon = new ImageIcon(FindSame.class.getResource(imgBg));
		JPanel dialogPanel = new JPanel(new BorderLayout());
		JLabel messageLabel = new JLabel(imageIcon);

//		messageLabel.setIcon(Image);
		messageLabel.setHorizontalTextPosition(JLabel.CENTER);
		messageLabel.setVerticalTextPosition(JLabel.TOP);
		dialogPanel.add(messageLabel, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel(new FlowLayout());
		JButton checkButton = new JButton("확인");
		JButton againButton = new JButton("재시작");
		Font buttonFont = new Font("NanumGothic", Font.BOLD, 20); // 20포인트 크기의 NanumGothic 폰트
		checkButton.setFont(buttonFont);
		againButton.setFont(buttonFont);
		
		// 버튼의 가로와 세로 크기를 설정합니다.
		checkButton.setPreferredSize(new Dimension(150, 50)); // 가로 100, 세로 50
		againButton.setPreferredSize(new Dimension(150, 50)); // 가로 100, 세로 50
		// 배경색을 설정합니다.
		checkButton.setBackground(Color.white); // 배경색을 흰색으로 설정
		againButton.setBackground(Color.white); // 배경색을 흰색으로 설정
		
		buttonPanel.add(checkButton);
		buttonPanel.add(againButton);
		dialogPanel.add(buttonPanel, BorderLayout.SOUTH);
		JFrame dialogFrame = new JFrame("게임 오버");
		dialogFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dialogFrame.getContentPane().add(dialogPanel);
		dialogFrame.setSize(400, 400);
		dialogFrame.setLocationRelativeTo(mainPanel);
		dialogFrame.setVisible(true);
		checkButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialogFrame.dispose(); // 다이얼로그 창 닫기
				frame.dispose(); // 기존의 프레임 닫기
				FindSameJFrame.mainScreen(); // 메인 화면 다시 열기
			}
		});
		againButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialogFrame.dispose(); // 다이얼로그 창 닫기
				frame.dispose(); // 기존의 프레임 닫기
				resetGame(); // 게임 재시작
			}
		});
	}

	private static void resetGame() {
		mainPanel.removeAll();
		mainPanel.revalidate();
		mainPanel.repaint();

		gameStart();
	}
}
